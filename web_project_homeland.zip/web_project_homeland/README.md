# Web Project Homeland

Este é o Projeto 5 da **TripleTen**, onde desenvolvemos uma página web para mostrar as cidades natais de alguns funcionários da empresa. O projeto foca em criar um layout responsivo utilizando o Figma como base para o design.

## Descrição do Projeto

O **web_project_homeland** é uma página web responsiva, projetada para apresentar informações de diferentes cidades de forma visualmente atraente e adaptável a diversos dispositivos. Este projeto é dividido em duas partes:

1. Desenvolvimento de um layout responsivo com Figma como roteiro.
2. Implementação das consultas de mídia para suportar telas de 320px, 768px e 1280px.

## Funcionalidade

- Visualizar informações de cidades de origem dos funcionários.
- Adaptabilidade a múltiplos tamanhos de tela, mantendo a qualidade visual do layout em dispositivos móveis, tablets e desktops.
- Layout otimizado com uso de CSS Flexbox e consultas de mídia.

## Tecnologias e Ferramentas Utilizadas

- **HTML5**: Estrutura semântica para uma melhor acessibilidade.
- **CSS3**: Para estilização, flexbox, media queries e responsividade.
- **Metodologia BEM**: Para manter a estrutura e organização do CSS.
- **Figma**: Ferramenta de design para prototipagem e desenvolvimento do layout.
- **Git/GitHub**: Controle de versão e repositório remoto.

## Estrutura de Pastas

O projeto segue uma estrutura de pastas baseada na metodologia BEM Flat:

```
├── blocks/
│   ├── footer.css
│   ├── header.css
│   ├── intro.css
│   ├── lead.css
│   └── page.css
├── images/
├── pages/
│   └── index.css
├── vendor/
│   ├── fonts.css
│   ├── normalize.css
│   ├── /fonts/
│   └──  Inter-web
├── .editorconfig
├── .gitignore
├── .prettierignore
├── index.html
└── .prettierignore
```

### Checklist de Conformidade

1. Todos os blocos seguem a metodologia BEM.
2. Responsividade garantida com pontos de interrupção em 544px e 1024px.
3. Fonte Inter usada e conectada localmente, com fontes do sistema como fallback.
4. O código foi validado no W3C e segue as boas práticas de formatação e acessibilidade.
